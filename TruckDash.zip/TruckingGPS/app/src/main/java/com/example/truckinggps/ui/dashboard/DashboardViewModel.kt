package com.example.truckinggps.ui.dashboard

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.truckinggps.data.TelemetryData
import com.example.truckinggps.data.TelemetryRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ConnectionState {
    object Disconnected : ConnectionState
    object Connecting : ConnectionState
    object Connected : ConnectionState
    data class Error(val message: String) : ConnectionState
}

enum class SpeedUnit {
    KMH_DIRECT,
    MPH
}

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("trucksim_prefs", Context.MODE_PRIVATE)
    private val repository = TelemetryRepository()

    private val _serverIp = MutableStateFlow(prefs.getString("server_ip", "192.168.0.238:31377") ?: "192.168.0.238:31377")
    val serverIp: StateFlow<String> = _serverIp.asStateFlow()

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _telemetry = MutableStateFlow(TelemetryData())
    val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

    private val _speedUnit = MutableStateFlow(
        try {
            SpeedUnit.valueOf(prefs.getString("speed_unit", SpeedUnit.KMH_DIRECT.name) ?: SpeedUnit.KMH_DIRECT.name)
        } catch (e: Exception) {
            SpeedUnit.KMH_DIRECT
        }
    )
    val speedUnit: StateFlow<SpeedUnit> = _speedUnit.asStateFlow()

    private val _useImperialDistance = MutableStateFlow(prefs.getBoolean("use_imperial_distance", false))
    val useImperialDistance: StateFlow<Boolean> = _useImperialDistance.asStateFlow()

    private val _useGallons = MutableStateFlow(prefs.getBoolean("use_gallons", false))
    val useGallons: StateFlow<Boolean> = _useGallons.asStateFlow()

    private var pollingJob: Job? = null

    init {
        connect()
    }

    fun updateServerIp(newIp: String) {
        _serverIp.value = newIp
        prefs.edit().putString("server_ip", newIp).apply()
        connect()
    }

    fun setSpeedUnit(unit: SpeedUnit) {
        _speedUnit.value = unit
        prefs.edit().putString("speed_unit", unit.name).apply()
    }

    fun setImperialDistance(imperial: Boolean) {
        _useImperialDistance.value = imperial
        prefs.edit().putBoolean("use_imperial_distance", imperial).apply()
    }

    fun setGallons(gallons: Boolean) {
        _useGallons.value = gallons
        prefs.edit().putBoolean("use_gallons", gallons).apply()
    }

    fun connect() {
        pollingJob?.cancel()
        _connectionState.value = ConnectionState.Connecting

        pollingJob = viewModelScope.launch {
            while (true) {
                try {
                    val data = repository.fetchTelemetry(_serverIp.value)
                    _telemetry.value = data
                    _connectionState.value = ConnectionState.Connected
                } catch (e: Exception) {
                    _connectionState.value = ConnectionState.Error(e.localizedMessage ?: "Connection failed")
                }
                delay(500L)
            }
        }
    }

    fun disconnect() {
        pollingJob?.cancel()
        pollingJob = null
        _connectionState.value = ConnectionState.Disconnected
    }

    override fun onCleared() {
        super.onCleared()
        pollingJob?.cancel()
        repository.close()
    }
}
