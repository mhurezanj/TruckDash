package com.example.truckinggps

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.truckinggps.ui.main.MainScreen
import com.example.truckinggps.ui.dashboard.DashboardViewModel
import com.example.truckinggps.ui.theme.TruckingGPSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TruckingGPSTheme {
                val viewModel: DashboardViewModel = viewModel()
                MainScreen(viewModel = viewModel)
            }
        }
    }
}
