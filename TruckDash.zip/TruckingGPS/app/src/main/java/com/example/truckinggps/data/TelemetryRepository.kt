package com.example.truckinggps.data

import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.request.get
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json

class TelemetryRepository {
    private val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json {
                ignoreUnknownKeys = true
                isLenient = true
                coerceInputValues = true
            })
        }
    }

    suspend fun fetchTelemetry(serverIp: String): TelemetryData {
        val cleanIp = serverIp.trim().removePrefix("http://").removePrefix("https://").removeSuffix("/")
        val telemetryUrl = "http://$cleanIp/api/ets2/telemetry"
        val jobUrl = "http://$cleanIp/api/ets2/job"
        val navUrl = "http://$cleanIp/api/ets2/navigation"

        val telemetryData: TelemetryData = client.get(telemetryUrl).body()

        var jobInfo = telemetryData.job
        var navInfo = telemetryData.navigation

        try {
            val jobResponse: JobInfo = client.get(jobUrl).body()
            jobInfo = jobResponse
        } catch (_: Exception) {
            // endpoint might not exist on this server version
        }

        try {
            val navResponse: NavigationInfo = client.get(navUrl).body()
            navInfo = navResponse
        } catch (_: Exception) {
            // endpoint might not exist on this server version
        }

        return telemetryData.copy(job = jobInfo, navigation = navInfo)
    }

    fun close() {
        client.close()
    }
}
