package com.example.truckinggps.ui.map

import androidx.compose.runtime.Composable
import com.example.truckinggps.ui.dashboard.DashboardViewModel

@Composable
fun MapScreen(viewModel: DashboardViewModel, onOpenSettings: () -> Unit) {
    // Stub
}
