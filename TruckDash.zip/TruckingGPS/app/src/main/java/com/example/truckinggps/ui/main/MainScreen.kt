package com.example.truckinggps.ui.main

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.example.truckinggps.ui.dashboard.DashboardScreen
import com.example.truckinggps.ui.dashboard.DashboardViewModel
import com.example.truckinggps.ui.dashboard.SettingsDialog
import com.example.truckinggps.ui.dashboard.SpeedUnit

@Composable
fun MainScreen(viewModel: DashboardViewModel) {
    val serverIp by viewModel.serverIp.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    val useImperialDistance by viewModel.useImperialDistance.collectAsState()
    val useGallons by viewModel.useGallons.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()

    var showSettingsDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        DashboardScreen(
            viewModel = viewModel,
            onOpenSettings = { showSettingsDialog = true }
        )
    }

    if (showSettingsDialog) {
        SettingsDialog(
            currentIp = serverIp,
            currentSpeedUnit = speedUnit,
            currentImperialDistance = useImperialDistance,
            currentGallons = useGallons,
            connectionState = connectionState,
            onDismiss = { showSettingsDialog = false },
            onSave = { newIp: String, newSpeedUnit: SpeedUnit, newImperial: Boolean, newGallons: Boolean ->
                viewModel.updateServerIp(newIp)
                viewModel.setSpeedUnit(newSpeedUnit)
                viewModel.setImperialDistance(newImperial)
                viewModel.setGallons(newGallons)
                showSettingsDialog = false
            },
            onReconnect = { viewModel.connect() }
        )
    }
}
