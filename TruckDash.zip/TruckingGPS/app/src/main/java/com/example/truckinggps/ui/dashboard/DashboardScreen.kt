package com.example.truckinggps.ui.dashboard

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.truckinggps.data.JobInfo
import com.example.truckinggps.data.NavigationInfo
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(viewModel: DashboardViewModel, onOpenSettings: () -> Unit) {
    val telemetry by viewModel.telemetry.collectAsState()
    val speedUnit by viewModel.speedUnit.collectAsState()
    val useGallons by viewModel.useGallons.collectAsState()
    val useImperialDistance by viewModel.useImperialDistance.collectAsState()
    val connectionState by viewModel.connectionState.collectAsState()

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (isLandscape) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    SpeedometerCard(
                        speedRaw = telemetry.truck.speed,
                        gear = telemetry.truck.gear,
                        displayedGear = telemetry.truck.displayedGear,
                        speedUnit = speedUnit,
                        cruiseControlSpeed = telemetry.truck.cruiseControlSpeed
                    )

                    TruckStatsCard(
                        rpm = telemetry.truck.engineRpm,
                        maxRpm = telemetry.truck.engineRpmMax,
                        fuel = telemetry.truck.fuel,
                        fuelCapacity = telemetry.truck.fuelCapacity,
                        make = telemetry.truck.make,
                        model = telemetry.truck.model,
                        odometer = telemetry.truck.odometer,
                        retarder = telemetry.truck.retarderBrake,
                        useGallons = useGallons,
                        useImperialDistance = useImperialDistance
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    GameStatusCard(
                        currentGameTime = telemetry.game.time,
                        nextRestStopTime = telemetry.game.nextRestStopTime,
                        isPaused = telemetry.game.paused,
                        estimatedTime = telemetry.navigation.estimatedTime
                    )

                    JobDetailsCard(
                        job = telemetry.job,
                        navigation = telemetry.navigation,
                        useImperialDistance = useImperialDistance
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                SpeedometerCard(
                    speedRaw = telemetry.truck.speed,
                    gear = telemetry.truck.gear,
                    displayedGear = telemetry.truck.displayedGear,
                    speedUnit = speedUnit,
                    cruiseControlSpeed = telemetry.truck.cruiseControlSpeed
                )

                TruckStatsCard(
                    rpm = telemetry.truck.engineRpm,
                    maxRpm = telemetry.truck.engineRpmMax,
                    fuel = telemetry.truck.fuel,
                    fuelCapacity = telemetry.truck.fuelCapacity,
                    make = telemetry.truck.make,
                    model = telemetry.truck.model,
                    odometer = telemetry.truck.odometer,
                    retarder = telemetry.truck.retarderBrake,
                    useGallons = useGallons,
                    useImperialDistance = useImperialDistance
                )

                GameStatusCard(
                    currentGameTime = telemetry.game.time,
                    nextRestStopTime = telemetry.game.nextRestStopTime,
                    isPaused = telemetry.game.paused,
                    estimatedTime = telemetry.navigation.estimatedTime
                )

                JobDetailsCard(
                    job = telemetry.job,
                    navigation = telemetry.navigation,
                    useImperialDistance = useImperialDistance
                )
            }
        }

        // Floating Top-Right Overlay: Connection Status Badge + Settings Wheel
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ConnectionBadge(connectionState = connectionState, onClick = onOpenSettings)

            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f))
            ) {
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        Icons.Default.Settings,
                        contentDescription = "Settings",
                        modifier = Modifier.size(22.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun ConnectionBadge(connectionState: ConnectionState, onClick: () -> Unit) {
    val (color, label) = when (connectionState) {
        is ConnectionState.Connected -> Color(0xFF4CAF50) to "Live"
        is ConnectionState.Connecting -> Color(0xFFFF9800) to "Sync"
        is ConnectionState.Disconnected -> Color(0xFF9E9E9E) to "Offline"
        is ConnectionState.Error -> Color(0xFFF44336) to "Error"
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f),
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Surface(
                modifier = Modifier.size(10.dp),
                shape = CircleShape,
                color = color
            ) {}
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun SpeedometerCard(
    speedRaw: Float,
    gear: Int,
    displayedGear: Int,
    speedUnit: SpeedUnit,
    cruiseControlSpeed: Float
) {
    val speedKmh = speedRaw
    val (finalSpeed, unitLabel) = when (speedUnit) {
        SpeedUnit.KMH_DIRECT -> Pair(speedKmh, "km/h")
        SpeedUnit.MPH -> Pair(speedKmh * 0.621371f, "mph")
    }

    val gearString = when {
        gear < 0 -> "R"
        gear == 0 -> "N"
        displayedGear > 0 -> "$displayedGear"
        else -> "$gear"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = "${finalSpeed.roundToInt()}",
                    style = MaterialTheme.typography.displayLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = unitLabel,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (cruiseControlSpeed > 0f) {
                    val ccKmh = cruiseControlSpeed
                    val ccSpeed = when (speedUnit) {
                        SpeedUnit.KMH_DIRECT -> ccKmh
                        SpeedUnit.MPH -> ccKmh * 0.621371f
                    }.roundToInt()
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "CC: $ccSpeed $unitLabel",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            // Gear Display Box
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(80.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = gearString,
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "GEAR",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TruckStatsCard(
    rpm: Float,
    maxRpm: Float,
    fuel: Float,
    fuelCapacity: Float,
    make: String?,
    model: String?,
    odometer: Float,
    retarder: Int,
    useGallons: Boolean,
    useImperialDistance: Boolean
) {
    val displayedFuel = if (useGallons) fuel * 0.264172f else fuel
    val displayedCapacity = if (useGallons) fuelCapacity * 0.264172f else fuelCapacity
    val fuelUnitLabel = if (useGallons) "gal" else "L"
    val odoVal = if (useImperialDistance) odometer * 0.621371f else odometer
    val odoUnit = if (useImperialDistance) "mi" else "km"

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${make ?: "Truck"} ${model ?: "Simulator"}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Odo: ${odoVal.roundToInt()} $odoUnit",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // RPM Progress
            val rpmProgress = (rpm / (if (maxRpm > 0f) maxRpm else 2500f)).coerceIn(0f, 1f)
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Engine RPM", style = MaterialTheme.typography.bodyMedium)
                    Text("${rpm.roundToInt()} RPM", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                LinearProgressIndicator(
                    progress = { rpmProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = if (rpm > 2000f) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
            }

            // Fuel Level Progress
            val fuelProgress = if (fuelCapacity > 0f) (fuel / fuelCapacity).coerceIn(0f, 1f) else 0f
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Fuel Level", style = MaterialTheme.typography.bodyMedium)
                    Text("${displayedFuel.roundToInt()} $fuelUnitLabel / ${displayedCapacity.roundToInt()} $fuelUnitLabel", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                }
                LinearProgressIndicator(
                    progress = { fuelProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = Color(0xFF4CAF50),
                )
            }

            if (retarder > 0) {
                AssistChip(
                    onClick = {},
                    label = { Text("Retarder: L$retarder") }
                )
            }
        }
    }
}

@Composable
fun GameStatusCard(
    currentGameTime: String?,
    nextRestStopTime: String?,
    isPaused: Boolean,
    estimatedTime: String?
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Row: ETA + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val etaGameStr = formatEtaWithoutSeconds(estimatedTime)
                Text(
                    text = "ETA: $etaGameStr",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = if (isPaused) "Paused" else "Driving",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (isPaused) MaterialTheme.colorScheme.error else Color(0xFF4CAF50)
                )
            }

            HorizontalDivider()

            // Bottom Row: Real Time (ETA / 20) + Rest Countdown
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val realTimeStr = calculateRealTimeEta(estimatedTime)
                Text(
                    text = "Real Time: $realTimeStr",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val restMinutes = calculateRestRemainingMinutes(currentGameTime, nextRestStopTime)
                val restDisplay = if (restMinutes <= 0) "0h 0m" else formatDurationMinutes(restMinutes)
                val restColor = if (restMinutes <= 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface

                Text(
                    text = "☕ Rest: $restDisplay",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    color = restColor
                )
            }
        }
    }
}

fun parseTimeToMinutes(timeStr: String?): Int {
    if (timeStr.isNullOrBlank()) return 0
    val timePart = if (timeStr.contains("T")) timeStr.substringAfter("T").substringBefore("Z") else timeStr
    val parts = timePart.split(":")
    if (parts.size >= 2) {
        val h = parts[0].toIntOrNull() ?: 0
        val m = parts[1].toIntOrNull() ?: 0
        return h * 60 + m
    }
    return 0
}

fun parseEtaToMinutes(estimatedTime: String?): Int {
    if (estimatedTime.isNullOrBlank()) return 0
    val timePart = if (estimatedTime.contains("T")) estimatedTime.substringAfter("T").substringBefore("Z") else estimatedTime
    val parts = timePart.split(":")
    if (parts.size >= 2) {
        val h = parts[0].toIntOrNull() ?: 0
        val m = parts[1].toIntOrNull() ?: 0
        return h * 60 + m
    }
    return 0
}

fun formatEtaWithoutSeconds(estimatedTime: String?): String {
    val totalMins = parseEtaToMinutes(estimatedTime)
    if (totalMins <= 0) return "--"
    return formatDurationMinutes(totalMins)
}

fun calculateRealTimeEta(estimatedTime: String?): String {
    val totalMins = parseEtaToMinutes(estimatedTime)
    if (totalMins <= 0) return "--"
    val realMins = (totalMins / 20.0).roundToInt()
    return formatDurationMinutes(realMins)
}

fun calculateRestRemainingMinutes(currentGameTime: String?, nextRestStopTime: String?): Int {
    val currentMins = parseTimeToMinutes(currentGameTime)
    val restMins = parseTimeToMinutes(nextRestStopTime)
    if (restMins <= 0 || currentMins <= 0) return 999 // default if unknown
    var diff = restMins - currentMins
    if (diff < 0) {
        diff += 24 * 60 // wrap around midnight
    }
    return diff
}

fun formatDurationMinutes(totalMinutes: Int): String {
    val hrs = totalMinutes / 60
    val mins = totalMinutes % 60
    return if (hrs > 0) "${hrs}h ${mins}m" else "${mins}m"
}

@Composable
fun JobDetailsCard(
    job: JobInfo,
    navigation: NavigationInfo,
    useImperialDistance: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Active Job & Navigation",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            val cargoTitle = job.cargoName ?: job.cargo ?: "No Active Job"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Cargo: $cargoTitle", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                if (job.cargoMass > 0f) {
                    val massVal = if (useImperialDistance) job.cargoMass * 2.20462f else job.cargoMass
                    val massUnit = if (useImperialDistance) "lb" else "kg"
                    Text("${massVal.roundToInt()} $massUnit", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (!job.sourceCity.isNullOrBlank() && !job.destinationCity.isNullOrBlank()) {
                Text(
                    text = "From: ${job.sourceCity} ➔ To: ${job.destinationCity}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (job.income > 0) {
                Text(
                    text = "Job Income: \$${job.income}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF4CAF50)
                )
            }

            if (navigation.estimatedDistance > 0f) {
                HorizontalDivider()
                val distVal = if (useImperialDistance) navigation.estimatedDistance * 0.000621371f else navigation.estimatedDistance * 0.001f
                val distUnit = if (useImperialDistance) "mi" else "km"
                Text("Distance Remaining: ${distVal.roundToInt()} $distUnit", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
