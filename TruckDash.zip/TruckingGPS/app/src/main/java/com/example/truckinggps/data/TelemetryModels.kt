package com.example.truckinggps.data

import kotlinx.serialization.Serializable

@Serializable
data class TelemetryData(
    val game: GameInfo = GameInfo(),
    val truck: TruckInfo = TruckInfo(),
    val job: JobInfo = JobInfo(),
    val navigation: NavigationInfo = NavigationInfo()
)

@Serializable
data class GameInfo(
    val connected: Boolean = false,
    val paused: Boolean = false,
    val time: String? = null,
    val timeScale: Float = 20.0f,
    val version: String? = null,
    val telemetryVersion: String? = null,
    val nextRestStopTime: String? = null
)

@Serializable
data class TruckInfo(
    val speed: Float = 0f,
    val engineRpm: Float = 0f,
    val engineRpmMax: Float = 2500f,
    val gear: Int = 0,
    val displayedGear: Int = 0,
    val fuel: Float = 0f,
    val fuelCapacity: Float = 400f,
    val fuelRange: Float = 0f,
    val wearEngine: Float = 0f,
    val wearTransmission: Float = 0f,
    val wearCabin: Float = 0f,
    val wearChassis: Float = 0f,
    val wearWheels: Float = 0f,
    val make: String? = null,
    val model: String? = null,
    val odometer: Float = 0f,
    val cruiseControlSpeed: Float = 0f,
    val electricOn: Boolean = false,
    val engineOn: Boolean = false,
    val parkBrakeOn: Boolean = false,
    val retarderBrake: Int = 0
)

@Serializable
data class JobInfo(
    val cargoLoaded: Boolean = false,
    val cargoName: String? = null,
    val cargo: String? = null,
    val cargoId: String? = null,
    val cargoMass: Float = 0f,
    val sourceCity: String? = null,
    val sourceCompany: String? = null,
    val destinationCity: String? = null,
    val destinationCompany: String? = null,
    val income: Long = 0L,
    val deadlineTime: String? = null,
    val remainingTime: String? = null
)

@Serializable
data class NavigationInfo(
    val estimatedDistance: Float = 0f, // meters
    val estimatedTime: String? = null, // string/timestamp from server
    val speedLimit: Float = 0f
)
