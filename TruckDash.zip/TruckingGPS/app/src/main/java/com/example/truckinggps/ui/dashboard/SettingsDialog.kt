package com.example.truckinggps.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsDialog(
    currentIp: String,
    currentSpeedUnit: SpeedUnit,
    currentImperialDistance: Boolean,
    currentGallons: Boolean,
    connectionState: ConnectionState,
    onDismiss: () -> Unit,
    onSave: (String, SpeedUnit, Boolean, Boolean) -> Unit,
    onReconnect: () -> Unit
) {
    var ipText by remember { mutableStateOf(currentIp) }
    var speedUnit by remember { mutableStateOf(currentSpeedUnit) }
    var imperialDistance by remember { mutableStateOf(currentImperialDistance) }
    var gallons by remember { mutableStateOf(currentGallons) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("TruckDash Settings") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Telemetry Server Connection", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                
                OutlinedTextField(
                    value = ipText,
                    onValueChange = { ipText = it },
                    label = { Text("PC IP & Port (e.g. 192.168.0.238:31377)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val statusText = when (connectionState) {
                        is ConnectionState.Connected -> "Status: Connected"
                        is ConnectionState.Connecting -> "Status: Connecting..."
                        is ConnectionState.Disconnected -> "Status: Disconnected"
                        is ConnectionState.Error -> "Status: Error (${connectionState.message})"
                    }
                    Text(statusText, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = onReconnect) {
                        Text("Reconnect")
                    }
                }

                HorizontalDivider()

                Text("Units & Display", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = speedUnit == SpeedUnit.KMH_DIRECT,
                        onClick = { speedUnit = SpeedUnit.KMH_DIRECT }
                    )
                    Text("KM/H (Metric)")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = speedUnit == SpeedUnit.MPH,
                        onClick = { speedUnit = SpeedUnit.MPH }
                    )
                    Text("MPH (Imperial)")
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Use Miles for Distance", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = imperialDistance,
                        onCheckedChange = { imperialDistance = it }
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Use Gallons for Fuel", style = MaterialTheme.typography.bodyMedium)
                    Switch(
                        checked = gallons,
                        onCheckedChange = { gallons = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(ipText, speedUnit, imperialDistance, gallons) }) {
                Text("Save & Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
